<? 
$PAGEINFO["title"] = "Edit Licenses";
$PAGEINFO["filename"] = "control-licenses.php";
include_once( "layout/header.php" ); 
include_once( "backend/" . $PAGEINFO["filename"] );
?>

<h1><?=$PAGEINFO["title"]?></h1>

<h2>Existing Licenses</h2>

<table>
	<thead>
		<tr>
			<th>Title</th>
			<th>Description</th>
			<th>URL</th>
		</tr>
	</thead>
	
	<tbody>
		<? foreach( $licenses as $license ) { ?> 
		<tr>
			<td><?=$license["title"]?></td>
			<td><?=$license["description"]?></td>
			<td><?=$license["url"]?></td>
		</tr>
		<? } ?>
	</tbody>
</table>

<h2>Add New License</h2>

<?
/* Items:
 * license[title]
 * license[url]
 * license[description]
 * new-license
 * */
?>
<form method="post" class="cf">
	<div class="field">
		<label>License Title</label>
		<input type="text" name="license[title]" />
	</div>
	
	<div class="field">
		<label>URL</label>
		<input type="text" name="license[url]" />
	</div>
	
	<div class="clear"></div>
	
	<div class="field">
		<label>Description</label>
		<textarea name="license[description]"></textarea>
	</div>
	
	<div class="submit-button">
		<input type="submit" name="new-license" value="Add New License" />
	</div>	
</form>
			
<? include_once( "layout/footer.php" ); ?>
