<? 
$PAGEINFO["title"] = "Edit Authors";
$PAGEINFO["filename"] = "control-authors.php";
include_once( "layout/header.php" ); 
include_once( "backend/" . $PAGEINFO["filename"] );
?>

<h1><?=$PAGEINFO["title"]?></h1>

<h2>Existing Authors</h2>

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Email Address</th>
			<th>Homepage URL</th>
		</tr>
	</thead>
	
	<tbody>
		<? foreach( $authors as $author ) { ?> 
		<tr>
			<td><?=$author["name"]?></td> 
			<td><?=$author["email_address"]?></td> 
			<td><?=$author["homepage"]?></td>
		</tr>
		<? } ?>
	</tbody>
</table>

<h2>Add New Author</h2>

<?
/* Items:
 * author[name]
 * author[email_address]
 * author[homepage]
 * new-license
 * */
?>
<form method="post" class="cf">
	<div class="field">
		<label>Author Name / Username</label>
		<input type="text" name="author[name]" />
	</div>
	
	<div class="field">
		<label>Email Address</label>
		<input type="text" name="author[email_address]" />
	</div>
	
	<div class="field">
		<label>Homepage URL</label>
		<input type="text" name="author[homepage]" />
	</div>
	
	<div class="submit-button">
		<input type="submit" name="new-author" value="Add New Author" />
	</div>	
</form>
			
<? include_once( "layout/footer.php" ); ?>
