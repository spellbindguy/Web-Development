<? 
$PAGEINFO["title"] = "Edit Photos";
$PAGEINFO["filename"] = "control-photos.php";
include_once( "layout/header.php" ); 
include_once( "backend/" . $PAGEINFO["filename"] );
?>

<h1><?=$PAGEINFO["title"]?></h1>

<h2>Existing Photos</h2>

<table>
	<thead>
		<tr>
			<th>Photo Title</th>
			<th>Author Name</th>
			<th>License Type</th>
			<th>Filename</th>
			<th>Categories</th>
		</tr>
	</thead>
	
	<tbody>
		<? foreach( $photos as $photo ) { ?> 
		<tr>
			<td><?=$photo["photo_title"]?></td> 
			<td><?=$photo["author_name"]?></td> 
			<td><?=$photo["license_title"]?></td> 
			<td><?=$photo["filename"]?></td> 
			<td>
				<? /* all categories */ ?>
				<? foreach( $photo["categories"] as $category ) { ?>
					<?=$category?><br/>
				<? } ?>
			</td> 
		</tr>
		<? } ?>
	</tbody>
</table>

<h2>Add New Photo</h2>

<?
/* Items:
 * photo[title]
 * photo[filename]
 * photo[author-id]
 * photo[license-id]
 * category[i] = category_id
 * new-photo
 * */
?>
<form method="post" class="cf">
	<div class="field">
		<label>Title</label>
		<input type="text" name="photo[title]" />
	</div>
	
	<div class="field">
		<label>Filename</label>
		<input type="text" name="photo[filename]" />
	</div>
	
	<div class="clear"></div>
	
	<div class="field">
		<label>Author</label>
		<select name="photo[author_id]">
			<? foreach( $authors as $author ) { ?> 
				<option value="<?=$author["author_id"]?>"><?=$author["name"]?></option>
			<? } ?>
		</select>
	</div>
	
	<div class="clear"></div>
	
	<div class="field">
		<label>License</label>
		<select name="photo[license_id]">
			<? foreach( $licenses as $license ) { ?> 
				<option value="<?=$license["license_id"]?>"><?=$license["title"]?></option>
			<? } ?>
		</select>
	</div>
	
	<div class="clear"></div>
	
	<div class="field">
		<label><h3>Categories</h3></label>
		
		<?  $count = 0;
			foreach( $categories as $category ) { ?>
			<input type="checkbox" name="category[<?=$count?>" value="<?=$category['category_id']?>" id="category-<?=$category['category_id']?>" />
			
			<label for="category-<?=$category['category_id']?>">
				<?=$category["title"]?>
			</label>
		<? $count++;
		} ?> 
	</div>
	
	<div class="submit-button">
		<input type="submit" name="new-photo" value="Add New Photo" />
	</div>	
</form>
			
<? include_once( "layout/footer.php" ); ?>
