<? 
$PAGEINFO["title"] = "Edit Categories";
$PAGEINFO["filename"] = "control-categories.php";
include_once( "layout/header.php" ); 
include_once( "backend/" . $PAGEINFO["filename"] );
?>

<h1><?=$PAGEINFO["title"]?></h1>

<h2>Existing Categories</h2>

<table>
	<thead>
		<tr>
			<th>Title</th>
		</tr>
	</thead>
	
	<tbody>
		<? foreach( $categories as $category ) { ?> 
		<tr>
			<td><?=$category["title"]?></td> <? /* title */ ?>
		</tr>
		<? } ?>
	</tbody>
</table>

<h2>Add New Category</h2>

<?
/* Items:
 * category[title]
 * new-license
 * */
?>
<form method="post" class="cf">
	<div class="field">
		<label>Category Title</label>
		<input type="text" name="category[title]" />
	</div>
	
	<div class="submit-button">
		<input type="submit" name="new-category" value="Add New Category" />
	</div>	
</form>
			
<? include_once( "layout/footer.php" ); ?>
