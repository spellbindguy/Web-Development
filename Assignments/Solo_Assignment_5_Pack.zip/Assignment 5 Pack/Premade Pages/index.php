<? 
$PAGEINFO["title"] = "Photo Gallery";
$PAGEINFO["filename"] = "index.php";
include_once( "layout/header.php" ); 
include_once( "backend/" . $PAGEINFO["filename"] );
?>

<h1><?=$PAGEINFO["title"]?></h1>

<section class="gallery cf">
	
	<? foreach( $photos as $photo ) { ?>
		
		<div class="photo">
			<img src="images/<?=$photo['url']?>" title="<?=$photo['title']?>" />
			
			<span class="title"><?=$photo['title']?></span>
			<span class="author"><?=$photo['author']?></span>
			<span class="license"><?=$photo['license']?></span>
		</div>
		
	<? } ?>
	
</section>

<? include_once( "layout/footer.php" ); ?>
