<?
class Database
{
	// Fill out your database information here
	private $hostname = '';
	private $database = '';
	private $username = '';
	private $password = '';
	private $dbHandler = null;
	// Set this to false if you don't want all the debug output garbage
	private $debug = true;
	
	function __construct()  //
	{
		$this->OutputDebug( "Constructor" );
		$connection = "mysql:host=" . $this->hostname . ";";
		$connection .= "dbname=" . $this->database;
		
		try
		{
			$this->dbHandler = new PDO( 
				$connection,
				$this->username,
				$this->password
			);
		}
		catch( PDOException $error )
		{
			$this->OutputError( $error->getMessage() );
		}
	}

	function OutputError( $error ) 
	{
		echo( "<div class='error'>" );
		print_r( $error );
		echo( "</div>" );
	}
	
	function OutputDebug( $message ) 
	{
		if ( $this->debug ) 
		{
			echo( "<pre>" );
			print_r( $message );
			echo( "</pre>" );
		}
	}
	
	private function SelectQuery( $query ) 
	{
		$this->OutputDebug( $query );
		
		$rows = array();
		
		foreach( $this->dbHandler->query( $query ) as $row ) 
		{
			array_push( $rows, $row );
		}
		
		if ( $this->dbHandler->errorInfo()[2] != "" )
		{
			$this->OutputError( $this->dbHandler->errorInfo() );
		}
		
		$this->OutputDebug( $rows );
		return $rows;
	}
	
	private function InsertQuery( $query )
	{
		$this->OutputDebug( "Insert" );
		$this->OutputDebug( $query );
		
		$result = $this->dbHandler->exec( $query );
		
		$this->OutputDebug( $this->dbHandler->errorInfo() );
		$this->OutputDebug( $result );
	}
	
	/* SELECT FUNCTIONS */
	function SelectAllAuthors()
	{		
		// Select all records from the Author table
	}
	
	function SelectAllLicenses()
	{		
		// Select all records from the License table
	}
	
	function SelectAllCategories()
	{		
		// Select all records from the Categories table
	}
	
	function SelectAllPhotos()
	{		
		// Select the fields: title (Photo), name (Author), title (License), filename (Photo)
		// From the Photo table, with an inner join on the Author and License table (see spec)
	}
	
	function SelectCategoriesFor( $photo_id )
	{
		// Select the title field from the Category table,
		// Inner join on the PhotoCategory and Photo tables
		// Make sure only categories selected are the ones where the photo_id
		// match the $photo_id parameter (see spec)
	}
	
	/* INSERT FUNCTIONS */
	function InsertAuthor( $info )
	{
		// Insert items [name], [email_address], [homepage] into the Author table.
	}
	
	function InsertLicense( $info )
	{
		// Insert items [title], [description], [url] into the License table.
	}
	
	function InsertCategory( $info )
	{
		// Insert item [title] into the Category table.
	}
	
	function InsertPhoto( $info )
	{
		// Insert item [author_id], [license_id], [title], [filename] into the Photo table.
	}
	
	function InsertPhotoCategory( $info )
	{
		// Insert item [photo_id], [category_id] into the PhotoCategory table.
	}
}
?>

