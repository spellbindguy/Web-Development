</section>
		</section>
		
		<footer>
			<p>&copy; Alketo Industries, 1950 - <?= date( "Y" )?></p>
		</footer>
		
	</body>
</html>
