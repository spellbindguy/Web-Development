<!DOCTYPE html>
<html>
	<head>
		<title><?=$PAGEINFO["title"] ?></title>
		
		<link rel="stylesheet" href="style/style.css" type="text/css" />
	</head>
	
	<body>
		
		<header class="cf">
			<span class="page-name">ALKETO GALLERY</span>
			
			<nav>
				<ul class="cf">
					<li><a href="control-authors.php">Edit Authors</a></li>
					<li><a href="control-licenses.php">Edit Licenses</a></li>
					<li><a href="control-categories.php">Edit Categories</a></li>
					<li><a href="control-photos.php">Edit Photos</a></li>
					<li><a href="index.php">View Gallery</a></li>
				</ul>
			</nav>
		</header>
		
		<section class="main-container">
			<section class="main">
